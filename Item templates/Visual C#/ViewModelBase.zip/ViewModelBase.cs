﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace $rootnamespace$

/// <summary>
/// Contains base functionality for any viewmodel.
/// </summary>
abstract class $safeitemname$ : INotifyPropertyChanged, INotifyDataErrorInfo
{
    /// <summary>
    /// Collection of property names and list of associated errors.
    /// </summary>
    readonly Dictionary<string, List<string>> propertyErrors = new();

    public bool HasErrors => propertyErrors.Any();

    public event PropertyChangedEventHandler PropertyChanged;
    public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

    public IEnumerable GetErrors(string propertyName)
        => propertyErrors.GetValueOrDefault(propertyName, null);

    /// <summary>
    /// Adds an error to the list associated with the given property.
    /// </summary>
    /// <param name="propertyName">Name of a property from this viewmodel, bound to the associated view.</param>
    /// <param name="errorMessage">Text to be displayed if the property fails validation.</param>
    internal void AddError(string propertyName, string errorMessage)
    {
        if (!propertyErrors.ContainsKey(propertyName))
            propertyErrors.Add(propertyName, new());

        propertyErrors[propertyName].Add(errorMessage);
        OnErrorsChanged(propertyName);
    }

    /// <summary>
    /// Removes all errors associated with the given property.
    /// </summary>
    /// <param name="propertyName">Name of a property from this viewmodel, bound to the associated view.</param>
    internal void ClearErrors(string propertyName)
    {
        if (propertyErrors.Remove(propertyName))
            OnErrorsChanged(propertyName);
    }

    internal void OnPropertyChanged([CallerMemberName] string propertyName = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

    void OnErrorsChanged(string propertyName)
        => ErrorsChanged?.Invoke(this, new DataErrorsChangedEventArgs(propertyName));
}

